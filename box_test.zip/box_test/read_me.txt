controls:
	up: i
	down: k
	right: l
	left: j