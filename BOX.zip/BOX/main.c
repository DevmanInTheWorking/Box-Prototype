#include <stdio.h>

typedef struct
{
	int x;
	int y;
} position;

//variables
char map[6][6] = {
	{'_', '_', '_', '_', '_', '_'},
	{'|', ' ', ' ', ' ', ' ', '|'},
	{'|', ' ', ' ', ' ', ' ', '|'},
	{'|', ' ', ' ', ' ', ' ', '|'},
	{'|', ' ', ' ', ' ', ' ', '|'},
	{'|', '_', '_', '_', '_', '|'}
};

char player = 'A';
int run = 1;
char input;
char getRougeChar;

//functions
int printMap();
void ifStart();
void getInput();
void captureRougeChar();
void playerMoveRight();
void playerMoveLeft();
void playerMoveDown();
void playerMoveUp();
void whichPlayerMovement();

position playerPosition = {0, 0};

int main()
{
	printMap();
	printf("Enter S to start.\n");
	getInput();
	captureRougeChar();
	ifStart();
	while (run == 1)
	{
		printMap();
		getInput();
		whichPlayerMovement();
	}
}

int printMap()
{
	for (int i = 0; i < 6; i++)
	{
		for (int j = 0; j < 6; j++)
		{
			printf("%c", map[i][j]);
		}
		printf("\n");
	}
}

void getInput()
{
	scanf("%1c", &input);
}

void captureRougeChar()
{
	scanf("%c", &getRougeChar);
	getRougeChar = ' ';
}

void ifStart()
{
	if (input == 's' || input == 'S')
	{
		map[1][1] = player;
	}
	else 
	{
		run = 0;
	}
}

void whichPlayerMovement()
{
	if (input == 'l' || input == 'L')
	{
		playerMoveRight();
	}
	else if (input == 'j' || input == 'J')
	{
		playerMoveLeft();
	}
	else if (input == 'k' || input == 'K')
	{
		playerMoveDown();
	}
	else if (input == 'i' || input == 'I')
	{
		playerMoveUp();
	}
}

void playerMoveRight()
{
	if (playerPosition.x == 0 && playerPosition.y == 0)
	{
		map[1][1] = ' ';
		map[1][2] = player;
		playerPosition.x++;
	}
	else if (playerPosition.x == 1 && playerPosition.y == 0)
	{
		map[1][2] = ' ';
		map[1][3] = player;
		playerPosition.x++;
	}
	else if (playerPosition.x == 2 && playerPosition.y == 0)
	{
		map[1][3] = ' ';
		map[1][4] = player;
		playerPosition.x++;
	}
	else if (playerPosition.x == 3 && playerPosition.y == 0)
	{
		map[1][3] = ' ';
		map[1][4] = player;
		playerPosition.x++;
		playerPosition.x--;
	}
	else if (playerPosition.x == 0 && playerPosition.y == 1)
	{
		map[2][1] = ' ';
		map[2][2] = player;
		playerPosition.x++;
	}
	else if (playerPosition.x == 1 && playerPosition.y == 1)
	{
		map[2][2] = ' ';
		map[2][3] = player;
		playerPosition.x++;
	}
	else if (playerPosition.x == 2 && playerPosition.y == 1)
	{
		map[2][3] = ' ';
		map[2][4] = player;
		playerPosition.x++;
	}
	else if (playerPosition.x == 0 && playerPosition.y == 2)
	{
		map[3][1] = ' ';
		map[3][2] = player;
		playerPosition.x++;
	}
	else if (playerPosition.x == 1 && playerPosition.y == 2)
	{
		map[3][2] = ' ';
		map[3][3] = player;
		playerPosition.x++;
	}
	else if (playerPosition.x == 2 && playerPosition.y == 2)
	{
		map[3][3] = ' ';
		map[3][4] = player;
		playerPosition.x++;
	}
	else if (playerPosition.x == 3 && playerPosition.y == 2)
	{
		map[3][3] = ' ';
		map[3][4] = player;
		playerPosition.x++;
		playerPosition.x--;
	}
	else if (playerPosition.x == 0 && playerPosition.y == 3)
	{
		map[4][1] = ' ';
		map[4][2] = player;
		playerPosition.x++;
	}
	else if (playerPosition.x == 1 && playerPosition.y == 3)
	{
		map[4][2] = ' ';
		map[4][3] = player;
		playerPosition.x++;
	}
	else if (playerPosition.x == 2 && playerPosition.y == 3)
	{
		map[4][3] = ' ';
		map[4][4] = player;
		playerPosition.x++;
	}
	else if (playerPosition.x == 3 && playerPosition.y == 3)
	{
		map[4][3] = ' ';
		map[4][4] = player;
		playerPosition.x++;
		playerPosition.x--;
	}
}

void playerMoveLeft()
{
	if (playerPosition.x == 0 && playerPosition.y == 0)
	{
		map[1][1] = player;
		map[1][2] = ' ';
		playerPosition.x--;
		playerPosition.x++;
	}
	else if (playerPosition.x == 1 && playerPosition.y == 0)
	{
		map[1][2] = ' ';
		map[1][1] = player;
		playerPosition.x--;
	}
	else if (playerPosition.x == 2 && playerPosition.y == 0)
	{
		map[1][3] = ' ';
		map[1][2] = player;
		playerPosition.x--;
	}
	else if (playerPosition.x == 3 && playerPosition.y == 0)
	{
		map[1][4] = ' ';
		map[1][3] = player;
		playerPosition.x--;
	}
	else if (playerPosition.x == 0 && playerPosition.y == 1)
	{
		map[2][1] = player;
		map[2][2] = ' ';
		playerPosition.x--;
		playerPosition.x++;
	}
	else if (playerPosition.x == 1 && playerPosition.y == 1)
	{
		map[2][2] = ' ';
		map[2][1] = player;
		playerPosition.x--;
	}
	else if (playerPosition.x == 2 && playerPosition.y == 1)
	{
		map[2][3] = ' ';
		map[2][2] = player;
		playerPosition.x--;
	}
	else if (playerPosition.x == 3 && playerPosition.y == 1)
	{
		map[2][4] = ' ';
		map[2][3] = player;
		playerPosition.x--;
	}
	else if (playerPosition.x == 0 && playerPosition.y == 2)
	{
		map[3][1] = player;
		map[3][2] = ' ';
		playerPosition.x--;
		playerPosition.x++;
	}
	else if (playerPosition.x == 1 && playerPosition.y == 2)
	{
		map[3][2] = ' ';
		map[3][1] = player;
		playerPosition.x--;
	}
	else if (playerPosition.x == 2 && playerPosition.y == 2)
	{
		map[3][3] = ' ';
		map[3][2] = player;
		playerPosition.x--;
	}
	else if (playerPosition.x == 3 && playerPosition.y == 2)
	{
		map[3][4] = ' ';
		map[3][3] = player;
		playerPosition.x--;
	}
	else if (playerPosition.x == 0 && playerPosition.y == 3)
	{
		map[4][1] = player;
		map[4][2] = ' ';
		playerPosition.x--;
	}
	else if (playerPosition.x == 1 && playerPosition.y == 3)
	{
		map[4][2] = ' ';
		map[4][1] = player;
		playerPosition.x--;
	}
	else if (playerPosition.x == 2 && playerPosition.y == 3)
	{
		map[4][3] = ' ';
		map[4][2] = player;
		playerPosition.x--;
	}
	else if (playerPosition.x == 3 && playerPosition.y == 3)
	{
		map[4][4] = ' ';
		map[4][3] = player;
		playerPosition.x--;
	}
}

void playerMoveDown()
{
	if (playerPosition.x == 0 && playerPosition.y == 0)
	{
		map[1][1] = ' ';
		map[2][1] = player;
		playerPosition.y++;
	}
	else if (playerPosition.x == 1 && playerPosition.y == 0)
	{
		map[1][2] = ' ';
		map[2][2] = player;
		playerPosition.y++;
	}
	else if (playerPosition.x == 2 && playerPosition.y == 0)
	{
		map[1][3] = ' ';
		map[2][3] = player;
		playerPosition.y++;
	}
	else if (playerPosition.x == 3 && playerPosition.y == 0)
	{
		map[1][4] = ' ';
		map[2][4] = player;
		playerPosition.y++;
	}
	else if (playerPosition.x == 0 && playerPosition.y == 1)
	{
		map[2][1] = ' ';
		map[3][1] = player;
		playerPosition.y++;
	}
	else if (playerPosition.x == 1 && playerPosition.y == 1)
	{
		map[2][2] = ' ';
		map[3][2] = player;
		playerPosition.y++;
	}
	else if (playerPosition.x == 2 && playerPosition.y == 1)
	{
		map[2][3] = ' ';
		map[3][3] = player;
		playerPosition.y++;
	}
	else if (playerPosition.x == 3 && playerPosition.y == 1)
	{
		map[2][4] = ' ';
		map[3][4] = player;
		playerPosition.y++;
	}
	else if (playerPosition.x == 0 && playerPosition.y == 2)
	{
		map[3][1] = ' ';
		map[4][1] = player;
		playerPosition.y++;
	}
	else if (playerPosition.x == 1 && playerPosition.y == 2)
	{
		map[3][2] = ' ';
		map[4][2] = player;
		playerPosition.y++;
	}
	else if (playerPosition.x == 2 && playerPosition.y == 2)
	{
		map[3][3] = ' ';
		map[4][3] = player;
		playerPosition.y++;
	}
	else if (playerPosition.x == 3 && playerPosition.y == 2)
	{
		map[3][4] = ' ';
		map[4][4] = player;
		playerPosition.y++;
	}
	else if (playerPosition.x == 0 && playerPosition.y == 3)
	{
		map[3][1] = ' ';
		map[4][1] = player;
		playerPosition.y++;
		playerPosition.y--;
	}
	else if (playerPosition.x == 1 && playerPosition.y == 3)
	{
		map[3][2] = ' ';
		map[4][2] = player;
		playerPosition.y++;
		playerPosition.y--;
	}
	else if (playerPosition.x == 2 && playerPosition.y == 3)
	{
		map[3][3] = ' ';
		map[4][3] = player;
		playerPosition.y++;
		playerPosition.y--;
	}
	else if (playerPosition.x == 3 && playerPosition.y == 3)
	{
		map[3][4] = ' ';
		map[4][4] = player;
		playerPosition.y++;
		playerPosition.y--;
	}
}

void playerMoveUp()
{
	if (playerPosition.x == 0 && playerPosition.y == 0)
	{
		map[1][1] = player;
		map[2][1] = ' ';
		playerPosition.y--;
		playerPosition.y++;
	}
	else if (playerPosition.x == 1 && playerPosition.y == 0)
	{
		map[1][2] = player;
		map[2][2] = ' ';
		playerPosition.y--;
		playerPosition.y++;
	}
	else if (playerPosition.x == 2 && playerPosition.y == 0)
	{
		map[1][3] = player;
		map[2][3] = ' ';
		playerPosition.y--;
		playerPosition.y++;
	}
	else if (playerPosition.x == 3 && playerPosition.y == 0)
	{
		map[1][4] = player;
		map[2][4] = ' ';
		playerPosition.y--;
		playerPosition.y++;
	}
	else if (playerPosition.x == 0 && playerPosition.y == 1)
	{
		map[1][1] = player;
		map[2][1] = ' ';
		playerPosition.y--;
	}
	else if (playerPosition.x == 1 && playerPosition.y == 1)
	{
		map[1][2] = player;
		map[2][2] = ' ';
		playerPosition.y++;
	}
	else if (playerPosition.x == 2 && playerPosition.y == 1)
	{
		map[1][3] = player;
		map[2][3] = ' ';
		playerPosition.y--;
	}
	else if (playerPosition.x == 3 && playerPosition.y == 1)
	{
		map[1][4] = player;
		map[2][4] = ' ';
		playerPosition.y--;
	}
	else if (playerPosition.x == 0 && playerPosition.y == 2)
	{
		map[2][1] = player;
		map[3][1] = ' ';
		playerPosition.y--;
	}
	else if (playerPosition.x == 1 && playerPosition.y == 2)
	{
		map[2][2] = player;
		map[3][2] = ' ';
		playerPosition.y--;
	}
	else if (playerPosition.x == 2 && playerPosition.y == 2)
	{
		map[2][3] = player;
		map[3][3] = ' ';
		playerPosition.y--;
	}
	else if (playerPosition.x == 3 && playerPosition.y == 2)
	{
		map[2][4] = player;
		map[3][4] = ' ';
		playerPosition.y--;
	}
	else if (playerPosition.x == 0 && playerPosition.y == 3)
	{
		map[3][1] = player;
		map[4][1] = ' ';
		playerPosition.y--;
	}
	else if (playerPosition.x == 1 && playerPosition.y == 3)
	{
		map[3][2] = player;
		map[4][2] = ' ';
		playerPosition.y--;
	}
	else if (playerPosition.x == 2 && playerPosition.y == 3)
	{
		map[3][3] = player;
		map[4][3] = ' ';
		playerPosition.y--;
	}
	else if (playerPosition.x == 3 && playerPosition.y == 3)
	{
		map[3][4] = player;
		map[4][4] = ' ';
		playerPosition.y--;
	}
}